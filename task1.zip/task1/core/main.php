<?php 
/* Author: Aizaz Ud Din (Aizaz.dinho)*/
	/* Made By: Meralesson.com*/
	session_start();
	include 'class/functions.php';
	include 'connection.php';
?>