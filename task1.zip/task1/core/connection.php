<?php
 try {
    $pdo = new PDO('mysql:host=localhost;dbname=task1', 'sammy', 'Nl9+U4&-kf}p');
     
} catch (PDOException $e) {
    print "Connetion Error!: " . $e->getMessage() . "<br/>";
    die();
}
?>
