  <?php
session_start();
$conn=mysqli_connect("localhost","sammy","Nl9+U4&-kf}p","task1");

if(!$conn)
{
die("Connection failed: " . mysqli_connect_error());
echo"error";
}
 if(isset($_POST['save'])){
 $img ="images/profile.jpg";
  $pwd =$_POST["password"];
 $password=md5($pwd);
        $sql = "INSERT INTO users(username, password, first_name, last_name, profile_image) VALUES ('".$_POST["username"]."', '".$password."', '".$_POST["first_name"]."', '".$_POST["last_name"]."', '".$img."')";
        $result = mysqli_query($conn,$sql);
 header("Location: index.php");
   }
?>
<html>
<body>
<div>
    <form method="post">
      <label>
        <span>username</span>
        <input type="text" name="username" />
      </label>
      <label>
        <span>first_name</span>
        <input type="text" name="first_name" />
      </label>
      <label>
        <span>last_name</span>
        <input type="text" name="last_name" />
      </label>
          <label>
            <span>Password</span>
        <input type="password" name="password" />
      </label>
      <button type="submit" name="save" class="submit">Sign Up</button>
    </form>
</div>
</body>
</html>